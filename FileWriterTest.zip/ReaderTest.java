package day_08;

import java.io.*;

public class ReaderTest {
    public static void main(String[] args) {
        /*
        try{
            InputStreamReader inputStreamReader = new InputStreamReader(System.in);
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(System.out);

            int num = inputStreamReader.read();
            outputStreamWriter.write(num);
            outputStreamWriter.flush();
            inputStreamReader.close();
            outputStreamWriter.close();

        }catch(IOException ioException){
            System.out.println("예외 발생");
            ioException.printStackTrace();
        }
*/
        InputStreamReader inputStreamReader = new InputStreamReader(System.in);
        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
        //BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));

        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(System.out);
        BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);
        //BufferedWriter bufferedWriter = bew BufferedWriter(new OutpuStreamWriter(System.out));

        try{
            String str = bufferedReader.readLine();

            bufferedWriter.write(str);
            bufferedWriter.flush();
            bufferedWriter.close();
            bufferedReader.close();
        }catch (IOException ioException){
            System.out.println("예외 발생");
            ioException.printStackTrace();
        }


    }
}
