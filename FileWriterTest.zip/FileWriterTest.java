package day_08;

import java.io.*;

public class FileWriterTest {
    public static void main(String[] args) {

        try{
            String path = "test.txt";
            File file = new File(path);

            FileWriter fileWriter = new FileWriter(file);

            for (int i = 'A'; i <= 'Z'; i++) {
                fileWriter.write(i);
            }
            fileWriter.close();


            FileReader fileReader = new FileReader(file);

            System.out.println(fileReader);
            fileReader.close();

        }catch (IOException ioException){
            System.out.println("예외 발생");
            ioException.printStackTrace();

        }
    }
}
