package day_08;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

// io : 1byte 데이터는 xxxInputStream, xxxOutputStream
//      2byte 데이터는 xxxReadder, xxxWriter
//
public class InputStreamTest {
    public static void main(String[] args) {

        try{
            InputStream inputStream = System.in;
            int num = inputStream.read();
            System.out.println((char)num);

        }catch (IOException ioException){
            System.out.println("예외 발생");
            ioException.printStackTrace();
        }


        OutputStream outputStream = System.out;




    }
}
