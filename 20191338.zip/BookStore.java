package org.javaro.lecture;
import java.util.ArrayList;
import org.javaro.lecture.Book;
import org.javaro.lecture.Student;

public class BookStore {
	public String storeName;
	public ArrayList<Book>books;
	public ArrayList<Student>students;
	public BookStore(String storeName) {
		this.storeName=storeName;
		books=new ArrayList<Book>();
		students=new ArrayList<Student>();
	}
	public String getStoreName() {
		return this.storeName;
	}
	public ArrayList<Book>getBooks(){
		return this.books;
	}
	public ArrayList<Student>getStudents(){
		return this.students;
	}
	public void addBook(Book book) {
		this.books.add(book);
	}
	public void removeBook(Book book) {
		this.books.remove(book);
	}
	public void addStudent(Student student) {
		this.students.add(student);
	}
	public void removeStudent(Student student) {
		this.students.remove(student);
	}
	public boolean checkOut(Book book, Student student) {
		if(book.getStudent()==null) {
			book.setStudent(student);
			return true;
		}
		else {
			return false;
		}
	}
	public boolean checkIn(Book book) {
		if(book.getStudent()!=null) {
			book.setStudent(null);
			return true;
		}
		else {
			return false;
		}
	}
	public ArrayList<Book> getBooksForStudent(Student student){
		ArrayList<Book> result=new ArrayList<Book>();
		for(Book aBook : this.getBooks()) {
			if((aBook.getStudent()!=null)&&(aBook.getStudent().getName().equals(student.getName()))){
				result.add(aBook);
			}
		}
		return result;
	}
	public ArrayList<Book> getAvailableBooks(){
		ArrayList<Book> result=new ArrayList<Book>();
		for(Book aBook : this.getBooks()) {
			if(aBook.getStudent()==null){
				result.add(aBook);
			}
		}
		return result;
	}
	public ArrayList<Book> getUnavailableBooks(){
		ArrayList<Book> result=new ArrayList<Book>();
		for(Book aBook : this.getBooks()) {
			if(aBook.getStudent()!=null){
				result.add(aBook);
			}
		}
		return result;
	}
	public String toString() {
		return this.getStoreName()+"�� ����å="+this.getBooks().size()+"��, ȸ����="+this.getStudents().size()+"��";
	}
	public void printStatus() {
		System.out.println("---������ ��Ȳ ---\n"+this.toString());
		for(Student student : this.getStudents()) {
			int count=this.getBooksForStudent(student).size();
			System.out.println(student+"��/�� "+count+"�� ������");
		}
		System.out.println("���� ���� ���� å : "+this.getAvailableBooks().size());
		System.out.println("--- ����Ʈ ���� ---");
	}
}
