package org.javaro.lecture;

public class Student {
	private String name;
	private int maxBooks;
	public Student() {
		this.name="nuknown name";
		this.maxBooks=3;
	}
	public String getName() {
		return this.name;
	}
	public int getMaxBooks() {
		return maxBooks;
	}
	public void setMaxBooks(int maxBooks) {
		this.maxBooks=maxBooks;
	}
	public void setName(String name) {
		this.name=name;
	}
	public String toString() {
		return "학생이름="+this.getName()+"(최대"+this.maxBooks+"권)";
	}

}
