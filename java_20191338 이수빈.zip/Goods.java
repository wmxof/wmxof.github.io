package org.javaro.lecture;

public class Goods {
	private String name;
	private int price;
	private int count;
	private int sale;
	private int maxPrice=(price*count)-sale;
	public Goods(String string, int mny) {
		this.name=string;
		this.price=mny;
		this.count=0;
	}
	public void setName(String name) {
		this.name=name;
	}
	public String getName() {
		return this.name;
	}
	public void setPrice(int price) {
		this.price=price;
	}
	public int getPrice() {
		return this.price;
	}
	public void setCount(int count) {
		this.count=count;
	}
	public int getCount() {
		return this.count;
	}
	public int getmaxPrice() {
		return getCount()*getPrice();
	}
	public String toString() {
		return "제목="+this.getName()+", 가격="+this.getPrice()+", 개수="+this.getCount()+", 예매 가격="+this.getmaxPrice();
	}

}