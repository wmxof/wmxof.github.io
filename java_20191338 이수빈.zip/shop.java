package org.javaro.lecture;
import java.util.*;

import org.javaro.lecture.Goods;

class shop {
	int after=0;
	ArrayList<Goods> goods1;
	shop(){
		goods1=new ArrayList<Goods>();
	}
	ArrayList<Goods> getGoods(){
		return this.goods1;
	}
	void addGoods(Goods goods) {
		this.goods1.add(goods);
	}
	void remove(Goods goods) {
		this.goods1.remove(goods);
	}
	public boolean checkOut(Goods goods) {
		if(this.getGoods()!=null) {
		after+=goods.getCount()*goods.getPrice();
		goods.setCount(0);
			return true;
		}
		else {
			return false;
		}
	}
	public boolean checkIn(Goods goods) {
		if(this.getGoods()!=null) {
			this.remove(goods);
			return true;
		}
		else {
			return false;
		}
	}
	void printStatus() {
		System.out.println();
		System.out.println("=====현재 상태 출력=====");
		System.out.println("---예매 현황---");
		for(Goods goods : this.getGoods()) {
			System.out.println(goods);
		}
		System.out.println();
		System.out.println("---구매 현황---\n"+after+"원 결재 완료");
		System.out.println("========================\n");
	}
	

}
