package org.javaro.lecture;
import org.javaro.lecture.Goods;

class MyShop {
	public static void main(String[]args) {
		System.out.println("프로젝트 과제"+"-"+"20191338 이수빈\n");
		shop myshop = new shop();
		Goods goods1=new Goods("마당을 나온 암탉",10350);
		Goods goods2=new Goods("나미야 잡화점의 기적",13320);
		Goods goods3=new Goods("죽고 싶지만 떡볶이는 먹고 싶어", 12420);
		Goods goods4=new Goods("돈의 속성", 16020);
		
		
		myshop.addGoods(goods1);
		myshop.addGoods(goods2);
		myshop.addGoods(goods3);
		

		
		System.out.println("온라인 서점");
		System.out.println("book1 마당을 나온 암탉 2권 예매");
		System.out.println("book3 죽고 싶지만 떡볶이는 먹고 싶어 4권 예매");
		
		goods1.setCount(2);
		goods3.setCount(4);
		myshop.printStatus();
		System.out.println("book1, book3 결재");
		myshop.checkOut(goods1);
		myshop.checkOut(goods3);
		myshop.printStatus();
		
		System.out.println("book2 나미야 잡화점의 기적 3권 예매");
		System.out.println("book4 돈의 속성 1권 예매");
		myshop.addGoods(goods4);
		goods2.setCount(3);
		goods4.setCount(1);
		myshop.printStatus();
		
		System.out.println("book2 나미야 잡화점의 기적을 예매 취소");
		myshop.remove(goods2);
		System.out.println("book4 결재");
		myshop.checkOut(goods4);
		myshop.printStatus();

	}
}
